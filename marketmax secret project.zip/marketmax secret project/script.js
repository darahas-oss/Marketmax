function searchProducts() {
    let input = document.getElementById("search-bar").value.toLowerCase();
    let products = document.querySelectorAll(".product");

    products.forEach(product => {
        let name = product.getAttribute("data-name").toLowerCase();
        product.style.display = name.includes(input) ? "block" : "none";
    });
}

function addToCart(productName) {
    alert(productName + " added to cart!");
}

function sendQuery() {
    let query = document.getElementById("chat-input").value;
    let responseBox = document.getElementById("chat-response");

    // Simulate AI response
    let responses = {
        "smartphone": "Our latest smartphone has 128GB storage and a 48MP camera!",
        "laptop": "Our laptop features a Core i7 processor and 16GB RAM."
    };

    let response = responses[query.toLowerCase()] || "Sorry, I don't have an answer for that.";
    responseBox.innerHTML = `<p>${response}</p>`;
}